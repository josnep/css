<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<!-- 从前面传来的数据 -->
	<?php foreach ($data as $key => $val) { ?>
		<!-- 判断类型 -->
		<?php if ($val['title_type'] == "1-单选") { ?>
			<p>第<?=$key+1?>题 : <?=$val['title_type']?> <?=$val['numbers']?>分</p>
			<p><?=$val['title']?></p>
			<?php foreach ($val['xuan_xiang'] as $k => $v ) { ?>
				<p>&nbsp&nbsp&nbsp&nbsp <input type="radio" name="<?=$val['title']?>"> <?=$v['answer']?> </p>
			<?php } ?>
		<?php }elseif($val['title_type'] == "2-多选") { ?>
			<p>第<?=$key+1?>题 : <?=$val['title_type']?> <?=$val['numbers']?>分</p>
			<p><?=$val['title']?></p>
			<?php foreach ($val['xuan_xiang'] as $k => $v ) { ?>
				<p>&nbsp&nbsp&nbsp&nbsp <input type="checkbox" name="<?=$val['title']?>"> <?=$v['answer']?> </p>
			<?php } ?>
		<?php }elseif($val['title_type'] == "0-判断") { ?>
			<p>第<?=$key+1?>题 : <?=$val['title_type']?> <?=$val['numbers']?>分</p>
			<p><?=$val['title']?></p>
			<?php foreach ($val['xuan_xiang'] as $k => $v ) { ?>
				<p>&nbsp&nbsp&nbsp&nbsp <input type="radio" name="<?=$val['title']?>"> <?=$v['answer']?> </p>
			<?php } ?>
		<?php } ?>
		
	<?php } ?>
	<center>
		<button type="submit" class="btn btn-success">提交试卷</button>
	</center>
	
</body>
</html>