<?php
namespace frontend\controllers;

use Yii;
use common\libs\curl;
use yii\web\Controller;


class ShowController extends Controller
{

	public function actionList(){
		return $this->render('list_topic');
	}
	public function actionUnit(){
		$url="http://39.105.74.249/css/yii2_gaoji/advanced/api/web/index.php?r=api/fshow";
	}


	//展示试题的
	public function actionIndex () {
		
		$url="http://39.105.74.249/css/yii2_gaoji/advanced/api/web/index.php?r=api/list";
		$arr=curl::_get($url);
		$data=json_decode($arr,true);
		// print_r($data);die;
		//渲染页面将数据展示到页面
		return $this->render('show',['data'=>$data]);
	}

}