<?php
namespace api\controllers;
use yii;
use yii\web\Controller;
/**
 * 
 */
class ApiController extends Controller
{
	public $enableCsrfValidation = false;

	public function actionIndex(){
		// var_dump($_FILES);die;
		//将文件保存到服务器中
		$dir = "/phpstudy/www/css/yii2_gaoji/advanced/api/image/".$_FILES['file']['name'];
		// echo $dir;die;
 		$excels=move_uploaded_file($_FILES['file']['tmp_name'], $dir);
 		//var_dump($excels);
 		$title=Yii::$app->request->post('title');

 		//引用Excel类
 		require(__DIR__ . '/../../common/libs/Classes/PHPExcel.php');
 		//初始化Excel
 		 // $excel=new \PHPExcel();

 		$objPHPExcel = \PHPExcel_IOFactory::load($dir);
 		// var_dump($objPHPExcel);die; 
 		$datas = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
 		// var_dump($datas);die;
 		unset($datas[1]);
 		// var_dump($datas);die;
 		//将二维数组变为一维数组
 		foreach ($datas as $key =>$val){
	 			//判断题的类型
	 			if ($val['B']=='1-单选'){
	 				//分数
	 				$numbers=3;
	 			}else{
	 				//分数
	 				$numbers=2;
	 			}
	 		//添加时间
	 		$addtime=time();
	 		//添加试题入库
	 		$sql="insert into title (title_type,title,addtime,numbers,dy_title) values('".$val['B']."','".$val['C']."','".$addtime."','".$numbers."','".$title."')";
	 		//执行SQL语句
	 		$res=Yii::$app->db->createCommand($sql)->execute();
	 		//当题如成功的时候把答案入库
	 		if($res){
	 			//新添加题目的ID(题的ID)
	 			$id=Yii::$app->db->getLastinsertID();
	 			//题的选项
	 			$options=array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');
	 			// print_r($option);die;
	 			//正确答案的选项
	 			$yesinfo=str_split($val['J'],1);
	 			// print_r($yesinfo);die;
	 			for($i ='D'; $i<='I'; $i++){
	 				//循环里面要是有空就不要他进来
	 				if (!empty($val[$i])) {
	 					//1代表正确答案，2代表错误的答案
	 					$yes_no = in_array($options[$i], $yesinfo) ? 1 : 2 ;
	 					//添加答案
	 					$sqls="insert into answer values ($id,'".$val[$i]."','".$yes_no."')";
	 					//添加入库
	 					$res=Yii::$app->db->createCommand($sqls)->execute();
	 				}
	 				
	 			}
	 			

	 		}else{
	 			echo "入库失败~~";
	 		}
 		}
 		
		
	}

	//展示试题(查询)传到前台
	public function actionList(){
		//查询的是题的表
		$sql="select * from title";
		$datas=Yii::$app->db->createCommand($sql)->queryAll();
		//定义一个空数组来进行放到一起
		$arr = array();
		foreach ($datas as $key => $val){
			//获取到题的id
			$id=$val['id'];
			//通过题的id来进行查询他的答案表
			$sqls="select * from answer where id=".$id;
			$res=Yii::$app->db->createCommand($sqls)->queryAll();
			
			$arr[$key]['dy_title']=$val['dy_title'];
			$arr[$key]['title_type']=$val['title_type'];
			$arr[$key]['numbers'] = $val['numbers'];
			$arr[$key]['title'] = $val['title'];
			foreach ($res as $k => $v){
				$arr[$key]['xuan_xiang'][$k] = $v;
				
			}
			
		}
		// print_r($arr);die;
		//返回json字符串
		echo json_encode($arr);

	}

	public function actionFshow(){
		//distinct是去除重的 distinct+你要除去的东西
		$sql="select distinct dy_title from title";
		$data=Yii::$app->db->createCommand($sql)->queryAll();
		echo json_encode($data);
		
	}

	
}

?>