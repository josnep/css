<?php
namespace backend\controllers;
use Yii;
use yii\web\Controller;

 class TestController extends Controller
 {
 	
 	public function actionIndex(){
 		$arr = "1234";

 		$data = str_split($arr,1);

 		var_dump($data);
 		die;
 	}




 } 
?>