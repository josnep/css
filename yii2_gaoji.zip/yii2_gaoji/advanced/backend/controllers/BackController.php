<?php
namespace backend\controllers;
use Yii;
use yii\web\Controller;
use common\libs\curl;
/**
  * 
  */
 class BackController extends Controller
 {
 	
 	public $enableCsrfValidation = false;

 	public function actionIndex(){
 		// require(__DIR__ . '/../../common/libs/Classes/PHPExcel.php');
 		// $excel=new \PHPExcel();
 		// var_dump($excel);die;
 		return $this->render('list');
 	}

 	//添加试题
 	public function actionAdd(){
 		return $this->render('add');
 	}
 	//进行接值
 	public function actionAdds(){
 		//接题目的值
 		$get=Yii::$app->request->post();
 		// print_r($get);die;
 		//文件上传
 		$excel=$_FILES['files'];
 		$dir = "/phpstudy/www/css/yii2_gaoji/advanced/backend/image/".$excel['name'];
 		$excels=move_uploaded_file($excel['tmp_name'], $dir);
 		if ($excels==true){
 			//向API发送值
 			$url="http://39.105.74.249/css/yii2_gaoji/advanced/api/web/index.php?r=api/index";
 			$param['title']=$get['dy_title'];
 			$file['file']=$dir;

 			$reg=Curl::_post($url,$param,$file);
 			var_dump($reg);
 			// var_dump($file); die;
 			
 		}else{

 			echo '亲，上传试题出错了~~';
 		}
 		
 	}

 	//后台查看库里的几套题
 	public function actionShow(){
 		$url="http://39.105.74.249/css/yii2_gaoji/advanced/api/web/index.php?r=api/fshow";
 		$arr=curl::_get($url);
 		$data=json_decode($arr,true);
 		return $this->render('list',['data'=>$data]);
 		
 	}
 } 
?>