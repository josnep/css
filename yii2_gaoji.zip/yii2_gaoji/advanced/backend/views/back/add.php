<form role="form" action="index.php?r=back/adds" method="post" enctype="multipart/form-data">
	<!-- <input type="hidden" name="r" value="back/adds"> -->
	<div class="form-group">
	<label for="name">名称</label>
	<select name="dy_title">
		<option value="">请选择单元</option>
		<?php foreach(Yii::$app->params['dy_title'] as $k=>$val){?>
			<option value="<?=$val;?>"><?=$val;?></option>
		<?php }?>
	</select>
	</div>
	<div class="form-group">
			<label for="inputfile">文件输入</label>
			<input type="file" id="inputfile" name="files">
			<p class="help-block">导入的试题。</p>
		</div>
	<button type="submit" class="btn btn-default">提交试题</button>
</form>
