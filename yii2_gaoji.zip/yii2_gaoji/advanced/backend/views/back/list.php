<table class="table">
  <form action="index.php?" method="get">
      <input type="hidden" name='r' value="back/add">
      <button type="submit" class="btn btn-success">添加试题</button>
  </form>
    <thead>
      <tr>
          <th>科目(单元)</th>
    </thead>
     <?php foreach ($data as $key => $val){?>
    <tbody>
      <tr class="active">
          <td><?=$val['dy_title']?></td>
          
    </tbody>
     <?php }?>
</table>